seeds = string([56781234]);

TMax = 120;
DT = 0.00005;
NP_Wind=1e-8;
NP_RotSpd=1e-4;
NP_GenSpd=2e-4;
Np_tau_g=.9;
Np_P_g=10;
Np_beta=1.5e-3;
Np_LSS=1e-3;
Np_XY_ACC=5e-4;
Np_Tau_B=1e3;
Np_WY=5e-2;

alpha_gc=50; %1/20e-3;
eta_gc=0.85;
f_cut = 0.25;
w_cut = 2*pi*f_cut;

% fault = 1;
% pitches = [0;0;0];
% for i = 4:length(seeds)
%     % Rename input file
%     movefile('.\InflowWind\Wind\FAU_TurbSim_Hydro_' + seeds(i)...
%         + '.bts', '.\InflowWind\Wind\FAU_TurbSim_Hydro.bts');
% 
%     % Sensor scaling 0.95
%     FAST_InputFileName = 'Baseline.fst';
%     try
%         b = sim('Takuya', 'StopTime', '120');
%         save('TurbSim_' + seeds(i) + '_sensor' + '.mat', 'b');
%     catch ME
%     end
%     % Restore input file name
%     movefile('.\InflowWind\Wind\FAU_TurbSim_Hydro.bts',...
%         '.\InflowWind\Wind\FAU_TurbSim_Hydro_' + seeds(i) + '.bts');
% end

for j = 1:5
    fault = 0;
    for i = 1:length(seeds)
        % Rename input file
        movefile('.\InflowWind\Wind\FAU_TurbSim_Hydro_' + seeds(i)...
            + '.bts', '.\InflowWind\Wind\FAU_TurbSim_Hydro.bts');

        % Angles between 0 and 20 degrees in increments of 5
        pitches = [2 * pi * (j*5 - 5)/360;0;0];
        FAST_InputFileName = 'Baseline.fst';
        try
            b = sim('Takuya', 'StopTime', '120');
            save('TurbSim_' + seeds(i) + '_p' + string(pitches(1)) + '.mat',...
                'b');
        catch ME
        end
        % Restore input file name
        movefile('.\InflowWind\Wind\FAU_TurbSim_Hydro.bts',...
            '.\InflowWind\Wind\FAU_TurbSim_Hydro_' + seeds(i) + '.bts');
    end
end
